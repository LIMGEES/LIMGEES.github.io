GitHubCalendar(".calendar", "IonicaBizau", {
    responsive: true,
    tooltips: true
});
